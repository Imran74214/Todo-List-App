//check off specific todos by checking

$("ul").on("click","li", function(){
	$(this).toggleClass("completed");//this click refers to the li inside of ul
})


//click on X to delete todo
$("ul").on("click", "span", function(event){
$(this).parent().fadeOut(500,function(){
 $(this).remove(); //here $(this) refers to parent() which is li
});
event.stopPropagation();

})

$("input[type='text']").keypress(function(event){
	if(event.which===13){
		var todoText = $(this).val();
		$(this).val("");//to clear out input text
		$("ul").append("<li><span><i class='fa fa-trash'></i></span>"+" "+todoText+"</li>");//append takes an html element and appends it within the html condw
	}
})

$("#toggle-form").click(function(){
	$("input[type='text']").fadeToggle();
})